#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

void hello();

#ifdef __cplusplus
}
#endif
