//
// Created by Sorin Sebastian Mircea on 08/10/2020.
//

#include "AppStatus.h"

namespace da {
  namespace tools {
    bool AppStatus::AppStatus::isRunning = true;
  }
}