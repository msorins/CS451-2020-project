//
// Created by Sorin Sebastian Mircea on 08/10/2020.
//

#ifndef SRC_APPSTATUS_H
#define SRC_APPSTATUS_H

namespace da {
  namespace tools {
    class AppStatus {
    public:
      static bool isRunning;
    };
  }
}

#endif //SRC_APPSTATUS_H
