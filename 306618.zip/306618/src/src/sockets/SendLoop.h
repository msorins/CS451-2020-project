//
// Created by Sorin Sebastian Mircea on 10/10/2020.
//

#ifndef SRC_SENDLOOP_H
#define SRC_SENDLOOP_H

#include "FairLossSocket.h"

namespace da {
  namespace sockets {
    class SendLoop{
    public:
      void start_loop();

    };
  }
}



#endif //SRC_SENDLOOP_H
