
#ifndef SOCKET_TYPE
#define SOCKET_TYPE

namespace da
{
    namespace sockets
    {
        enum SocketType
        {
            RECEIVE = 0,
            SEND = 1
        };
    } // namespace sockets
} // namespace da

#endif